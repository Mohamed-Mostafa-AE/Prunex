# Prunex 0.4.3 Test Report

## Fresh build and automated test results

- Release build: GCC 14.2.0, CMake, Linux x86_64.
- Release CTest suite: 42/42 passed.
- Debug CTest suite with AddressSanitizer, UndefinedBehaviorSanitizer, and leak detection: 42/42 passed.
- `BUILD_TESTING=OFF`: previously verified to produce zero registered tests; no change to that option's CMake behavior.
- UCI protocol tests cover handshake/search, checkmate, stalemate, and a position requiring a quiet check evasion.
- Search-level tests directly exercise checkmate/stalemate horizon handling and quiet evasions in quiescence.
- FEN rejection tests cover malformed/overflowed move counters, negative halfmove clocks, zero fullmove numbers, extra fields, duplicate castling rights, and invalid en-passant state, including an occupied target square.
- White and Black en-passant move tests confirm legal captures are generated and pinned captures exposing the king are rejected.
- CLI argument tests cover negative/nonnumeric/overflowed perft depths, divide depth zero, and valid perft depth zero.
- GCC 14.2 static analysis (`-fanalyzer`) completed without diagnostics.
- Clang 17 Release build and CTest suite: 42/42 passed.
- Additional reference perft runs (manual, Release): start position depth 6 = 119,060,324; Kiwipete depth 4 = 4,085,603; standard position 5 depth 4 = 2,103,487; standard position 6 depth 4 = 3,894,594. These deeper runs were checked against their published counts but are not separate CTest registrations.

## Defects corrected during this pass

1. FEN parsing previously used `std::stoi` without exception handling. Nonnumeric counters aborted the process; trailing fields, duplicate castling rights, and inconsistent en-passant targets were accepted. Parsing now validates all six fields, counters, duplicate castling flags, and en-passant target/captured/origin squares. Regression tests cover these failures.
2. CLI perft depth arguments previously used `std::stoi` without validation. Negative depths could recurse until a stack overflow, and nonnumeric values aborted the process. Depths now use strict range checking, and regression tests cover invalid values and depth zero.
3. Quiescence previously used stand-pat evaluation while in check and searched captures only, which could miss quiet check evasions. It now searches all legal evasions when checked and recognizes checkmate/stalemate at the horizon. Dedicated tests cover those cases.
4. The Win32 GUI now defines `NOMINMAX` before including Windows headers to avoid macro collisions with `std::min` and `std::max` in the GUI source.
5. The Windows GUI and CLI output names previously differed only by case (`Prunex.exe` vs `prunex.exe`), which is unsafe on a case-insensitive filesystem. The Windows CLI target now emits `prunex-cli.exe`, and MSVC uses `/utf-8` for the Unicode chess-piece glyphs.

## Remaining limitations

- The native Windows GUI was not compiled or launched on Windows; the current environment has no Windows SDK or Windows runtime. `clang-cl` is present but cannot compile Win32 sources without those headers/libraries. A GitHub Actions workflow is included to perform the Windows build once the project is pushed to GitHub; that workflow has not yet been run.
- The GUI still performs search synchronously, so the window may block while the engine thinks.
- Promotion defaults to queen; no promotion-choice dialog is present.
- No Elo rating or match-performance claim has been established.
- No independent external AI review has been executed in this environment. The OpenAI review runner is included, but `OPENAI_API_KEY` is not available in this process. Run it locally using model IDs returned by `tools/openai_review.py --list-models`.
- The PowerShell helper is included but was not executed here because PowerShell is unavailable in this Linux environment.
- An exhaustive depth-4 run across every published perft position was not completed. Selected deeper reference positions were run manually and are listed above; they are separate from the 42 registered CTest checks.
