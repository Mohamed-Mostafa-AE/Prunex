#include <algorithm>
#include <array>
#include <cctype>
#include <chrono>
#include <charconv>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

namespace prunex {
constexpr int INF = 32000;
constexpr int MATE = 30000;
constexpr std::string_view START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

enum Piece : int { EMPTY=0, WP=1, WN, WB, WR, WQ, WK, BP=7, BN, BB, BR, BQ, BK };
enum Color : int { WHITE=0, BLACK=1 };
enum Castle : int { WKCA=1, WQCA=2, BKCA=4, BQCA=8 };

struct Move { int from=-1, to=-1, promotion=EMPTY; bool enPassant=false, castle=false; };
struct Position {
    std::array<int,128> board{};
    int side=WHITE, castling=0, ep=-1, halfmove=0, fullmove=1;
};
struct Undo { int captured=EMPTY, castling=0, ep=-1, halfmove=0, fullmove=1; };

constexpr bool onBoard(int s) { return s >= 0 && s < 128 && (s & 0x88) == 0; }
constexpr int fileOf(int s) { return s & 7; }
constexpr int rankOf(int s) { return s >> 4; }
constexpr int colorOf(int p) { return p == EMPTY ? -1 : (p <= WK ? WHITE : BLACK); }
constexpr int typeOf(int p) { return p == EMPTY ? EMPTY : ((p-1)%6)+1; }
constexpr int makePiece(int type, int color) { return type + (color == BLACK ? 6 : 0); }
std::string squareName(int s) { std::string x="a1"; x[0]=static_cast<char>('a'+fileOf(s)); x[1]=static_cast<char>('1'+rankOf(s)); return x; }
int parseSquare(std::string_view s) { if(s.size()!=2 || s[0]<'a'||s[0]>'h'||s[1]<'1'||s[1]>'8') return -1; return (s[1]-'1')*16+(s[0]-'a'); }
char pieceChar(int p) { static constexpr char chars[]=".PNBRQKpnbrqk"; return p>=0&&p<=12?chars[p]:'.'; }
int charPiece(char c) { switch(c) {case 'P':return WP;case 'N':return WN;case 'B':return WB;case 'R':return WR;case 'Q':return WQ;case 'K':return WK;case 'p':return BP;case 'n':return BN;case 'b':return BB;case 'r':return BR;case 'q':return BQ;case 'k':return BK;default:return EMPTY;} }

bool parseIntegerToken(std::string_view token, int minimum, int maximum, int& value) {
    int parsed=0;
    const char* first=token.data();
    const char* last=first+token.size();
    auto result=std::from_chars(first,last,parsed);
    if(result.ec!=std::errc{}||result.ptr!=last||parsed<minimum||parsed>maximum) return false;
    value=parsed;
    return true;
}

bool parseFenCounter(const std::string& token, int minimum, int& value) {
    return parseIntegerToken(token,minimum,std::numeric_limits<int>::max(),value);
}

bool loadFen(Position& p, std::string_view fen) {
    p=Position{};
    std::istringstream in{std::string(fen)};
    std::string placement, stm, rights, ep, halfmove, fullmove, extra;
    if(!(in>>placement>>stm>>rights>>ep>>halfmove>>fullmove)||(in>>extra)) return false;
    int rank=7,file=0;
    bool previousDigit=false;
    for(char c:placement) {
        if(c=='/') {
            if(file!=8 || rank==0) return false;
            --rank;
            file=0;
            previousDigit=false;
        } else if(c>='1'&&c<='8') {
            if(previousDigit) return false;
            file+=c-'0';
            if(file>8) return false;
            previousDigit=true;
        } else {
            int pc=charPiece(c);
            if(pc==EMPTY||file>=8) return false;
            p.board[rank*16+file]=pc;
            ++file;
            previousDigit=false;
        }
    }
    if(rank!=0||file!=8) return false;
    if(stm!="w"&&stm!="b") return false;
    p.side=stm=="w"?WHITE:BLACK;
    if(rights!="-") {
        for(char c:rights) {
            int bit=0;
            if(c=='K') bit=WKCA;
            else if(c=='Q') bit=WQCA;
            else if(c=='k') bit=BKCA;
            else if(c=='q') bit=BQCA;
            else return false;
            if(p.castling&bit) return false;
            p.castling|=bit;
        }
    }
    p.ep=ep=="-"?-1:parseSquare(ep);
    if(ep!="-"&&p.ep<0) return false;
    if(p.ep>=0){
        int expectedRank=p.side==WHITE?5:2;
        int capturedSquare=p.ep+(p.side==WHITE?-16:16);
        int originSquare=p.ep+(p.side==WHITE?16:-16);
        if(rankOf(p.ep)!=expectedRank||p.board[p.ep]!=EMPTY||!onBoard(capturedSquare)||!onBoard(originSquare)) return false;
        if(p.board[capturedSquare]!=makePiece(1,1-p.side)||p.board[originSquare]!=EMPTY) return false;
    }
    if(!parseFenCounter(halfmove,0,p.halfmove)||!parseFenCounter(fullmove,1,p.fullmove)) return false;
    int wk=0,bk=0;
    for(int s=0;s<128;++s) if(onBoard(s)) { wk+=p.board[s]==WK; bk+=p.board[s]==BK; }
    return wk==1&&bk==1;
}

bool attacked(const Position& p,int sq,int by) {
    const int pawn=makePiece(1,by), knight=makePiece(2,by);
    const int pawnSources[2]={sq+(by==WHITE?-15:15),sq+(by==WHITE?-17:17)};
    for(int s:pawnSources)if(onBoard(s)&&p.board[s]==pawn)return true;
    constexpr int knights[8]={-33,-31,-18,-14,14,18,31,33};
    for(int d:knights){int s=sq+d;if(onBoard(s)&&p.board[s]==knight)return true;}
    constexpr int dirs[8]={-16,-1,1,16,-17,-15,15,17};
    for(int i=0;i<8;++i){int s=sq+dirs[i];bool first=true;while(onBoard(s)){int pc=p.board[s];if(pc){if(colorOf(pc)==by&&(typeOf(pc)==5||(first&&typeOf(pc)==6)||(i<4&&typeOf(pc)==4)||(i>=4&&typeOf(pc)==3)))return true;break;}first=false;s+=dirs[i];}}
    return false;
}
int kingSquare(const Position& p,int color){int k=makePiece(6,color);for(int s=0;s<128;++s)if(onBoard(s)&&p.board[s]==k)return s;return -1;}
bool inCheck(const Position& p,int color){int k=kingSquare(p,color);return k>=0&&attacked(p,k,1-color);}

void addMove(std::vector<Move>& out,int from,int to,int promo=EMPTY,bool ep=false,bool castle=false){out.push_back({from,to,promo,ep,castle});}
std::vector<Move> pseudoMoves(const Position& p) {
    std::vector<Move> out; out.reserve(96);
    constexpr int knightD[8]={-33,-31,-18,-14,14,18,31,33};
    constexpr int bishopD[4]={-17,-15,15,17}; constexpr int rookD[4]={-16,-1,1,16};
    for(int from=0;from<128;++from){if(!onBoard(from))continue;int pc=p.board[from];if(colorOf(pc)!=p.side)continue;int t=typeOf(pc);
        if(t==1){int step=p.side==WHITE?16:-16;int one=from+step;int last=p.side==WHITE?7:0;
            if(onBoard(one)&&p.board[one]==EMPTY){if(rankOf(one)==last){for(int pr:{5,4,3,2})addMove(out,from,one,makePiece(pr,p.side));}else{addMove(out,from,one);int two=one+step;if(rankOf(from)==(p.side==WHITE?1:6)&&p.board[two]==EMPTY)addMove(out,from,two);}}
            for(int df:{-1,1}){int to=one+df;if(!onBoard(to))continue;if(colorOf(p.board[to])==1-p.side){if(rankOf(to)==last){for(int pr:{5,4,3,2})addMove(out,from,to,makePiece(pr,p.side));}else addMove(out,from,to);}else if(to==p.ep)addMove(out,from,to,EMPTY,true);}
        } else if(t==2){for(int d:knightD){int to=from+d;if(onBoard(to)&&colorOf(p.board[to])!=p.side)addMove(out,from,to);}}
        else {auto slide=[&](const int* ds,int count,bool repeat){for(int i=0;i<count;++i){int to=from+ds[i];while(onBoard(to)){if(colorOf(p.board[to])==p.side)break;addMove(out,from,to);if(p.board[to]!=EMPTY||!repeat)break;to+=ds[i];}}};
            if(t==3)slide(bishopD,4,true);else if(t==4)slide(rookD,4,true);else if(t==5){slide(bishopD,4,true);slide(rookD,4,true);}else if(t==6){constexpr int kingD[8]={-17,-16,-15,-1,1,15,16,17};slide(kingD,8,false);
                if(p.side==WHITE&&from==4&&!inCheck(p,WHITE)){if((p.castling&WKCA)&&p.board[5]==EMPTY&&p.board[6]==EMPTY&&p.board[7]==WR&&!attacked(p,5,BLACK)&&!attacked(p,6,BLACK))addMove(out,from,6,EMPTY,false,true);if((p.castling&WQCA)&&p.board[1]==EMPTY&&p.board[2]==EMPTY&&p.board[3]==EMPTY&&p.board[0]==WR&&!attacked(p,3,BLACK)&&!attacked(p,2,BLACK))addMove(out,from,2,EMPTY,false,true);}
                if(p.side==BLACK&&from==116&&!inCheck(p,BLACK)){if((p.castling&BKCA)&&p.board[117]==EMPTY&&p.board[118]==EMPTY&&p.board[119]==BR&&!attacked(p,117,WHITE)&&!attacked(p,118,WHITE))addMove(out,from,118,EMPTY,false,true);if((p.castling&BQCA)&&p.board[113]==EMPTY&&p.board[114]==EMPTY&&p.board[115]==EMPTY&&p.board[112]==BR&&!attacked(p,115,WHITE)&&!attacked(p,114,WHITE))addMove(out,from,114,EMPTY,false,true);}
            }}
    }return out;
}

Undo makeMove(Position& p,const Move& m){Undo u{p.board[m.to],p.castling,p.ep,p.halfmove,p.fullmove};int pc=p.board[m.from];p.board[m.from]=EMPTY;p.board[m.to]=m.promotion?m.promotion:pc;
    if(m.enPassant){int cap=m.to+(p.side==WHITE?-16:16);u.captured=p.board[cap];p.board[cap]=EMPTY;}
    if(m.castle){if(m.to>m.from){p.board[m.from+1]=p.board[m.from+3];p.board[m.from+3]=EMPTY;}else{p.board[m.from-1]=p.board[m.from-4];p.board[m.from-4]=EMPTY;}}
    if(pc==WK)p.castling&=~(WKCA|WQCA);
    if(pc==BK)p.castling&=~(BKCA|BQCA);
    if(m.from==0||m.to==0)p.castling&=~WQCA;
    if(m.from==7||m.to==7)p.castling&=~WKCA;
    if(m.from==112||m.to==112)p.castling&=~BQCA;
    if(m.from==119||m.to==119)p.castling&=~BKCA;
    p.ep=(typeOf(pc)==1&&std::abs(m.to-m.from)==32)?(m.to+m.from)/2:-1;
    p.halfmove=(typeOf(pc)==1||u.captured!=EMPTY)?0:p.halfmove+1;if(p.side==BLACK)++p.fullmove;p.side=1-p.side;return u;}
void undoMove(Position& p,const Move& m,const Undo& u){p.side=1-p.side;if(p.side==BLACK)--p.fullmove;p.castling=u.castling;p.ep=u.ep;p.halfmove=u.halfmove;int pc=p.board[m.to];p.board[m.from]=m.promotion?makePiece(1,p.side):pc;p.board[m.to]=m.enPassant?EMPTY:u.captured;if(m.enPassant)p.board[m.to+(p.side==WHITE?-16:16)]=u.captured;if(m.castle){if(m.to>m.from){p.board[m.from+3]=p.board[m.from+1];p.board[m.from+1]=EMPTY;}else{p.board[m.from-4]=p.board[m.from-1];p.board[m.from-1]=EMPTY;}}}
std::vector<Move> legalMoves(Position& p){auto candidates=pseudoMoves(p);std::vector<Move> legal;legal.reserve(candidates.size());int us=p.side;for(const Move&m:candidates){Position q=p;makeMove(q,m);if(!inCheck(q,us))legal.push_back(m);}return legal;}
std::string moveUci(const Move&m){std::string s=squareName(m.from)+squareName(m.to);if(m.promotion){char c=static_cast<char>(std::tolower(pieceChar(m.promotion)));s+=c;}return s;}
bool parseUciMove(Position& p,std::string_view text,Move& result){for(const Move&m:legalMoves(p))if(moveUci(m)==text){result=m;return true;}return false;}

int evaluate(const Position& p){constexpr int value[7]={0,100,320,335,500,900,0};int score=0;for(int s=0;s<128;++s)if(onBoard(s)&&p.board[s]){int pc=p.board[s],c=colorOf(pc),t=typeOf(pc),r=c==WHITE?rankOf(s):7-rankOf(s),f=fileOf(s);int center=6-(std::abs(2*f-7)+std::abs(2*r-7))/2;int positional=0;if(t==1)positional=r*7+center*2;else if(t==2||t==3)positional=center*5;else if(t==4)positional=r*2;score+=(c==WHITE?1:-1)*(value[t]+positional);}return p.side==WHITE?score:-score;}

std::uint64_t nodes=0;
int quiescence(Position& p,int alpha,int beta,int qply,int searchPly){
    ++nodes;
    bool checked=inCheck(p,p.side);
    auto candidates=pseudoMoves(p);
    std::vector<Move> moves;
    moves.reserve(candidates.size());
    bool hasLegalMove=false;
    for(const Move& m:candidates){
        Position q=p;
        makeMove(q,m);
        if(inCheck(q,p.side)) continue;
        hasLegalMove=true;
        if(!checked&&p.board[m.to]==EMPTY&&!m.enPassant&&!m.promotion) continue;
        moves.push_back(m);
    }
    if(!hasLegalMove) return checked?-MATE+searchPly:0;
    if(!checked){
        int stand=evaluate(p);
        if(stand>=beta) return beta;
        if(stand>alpha) alpha=stand;
        if(qply>=12) return alpha;
        if(moves.empty()) return alpha;
    }
    for(const Move& m:moves){
        Position q=p;
        makeMove(q,m);
        int score=qply>=12?-evaluate(q):-quiescence(q,-beta,-alpha,qply+1,searchPly+1);
        if(score>=beta) return beta;
        if(score>alpha) alpha=score;
    }
    return alpha;
}
int negamax(Position& p,int depth,int alpha,int beta,int ply){if(depth<=0)return quiescence(p,alpha,beta,0,ply);++nodes;auto moves=legalMoves(p);if(moves.empty())return inCheck(p,p.side)?-MATE+ply:0;
    std::stable_sort(moves.begin(),moves.end(),[&](const Move&a,const Move&b){int va=(p.board[a.to]?10*typeOf(p.board[a.to])-typeOf(p.board[a.from]):0)+(a.promotion?100:0);int vb=(p.board[b.to]?10*typeOf(p.board[b.to])-typeOf(p.board[b.from]):0)+(b.promotion?100:0);return va>vb;});
    int best=-INF;for(const Move&m:moves){Position q=p;makeMove(q,m);int score=-negamax(q,depth-1,-beta,-alpha,ply+1);best=std::max(best,score);alpha=std::max(alpha,score);if(alpha>=beta)break;}return best;}
Move findBestMove(Position p,int depth){auto moves=legalMoves(p);if(moves.empty())return {};Move best=moves.front();int bestScore=-INF;nodes=0;for(const Move&m:moves){Position q=p;makeMove(q,m);int score=-negamax(q,depth-1,-INF,INF,1);if(score>bestScore){bestScore=score;best=m;}}std::cerr<<"info depth "<<depth<<" score cp "<<bestScore<<" nodes "<<nodes<<"\n";return best;}
std::uint64_t perft(Position& p,int depth){if(depth==0)return 1;auto moves=legalMoves(p);std::uint64_t n=0;for(const Move&m:moves){Position q=p;makeMove(q,m);n+=perft(q,depth-1);}return n;}

void setPosition(Position& p,const std::string& command){std::istringstream in(command);std::string token;in>>token;in>>token;if(token=="startpos")loadFen(p,START_FEN);else if(token=="fen"){std::string fen,part;for(int i=0;i<6&&in>>part;++i){if(i)fen+=' ';fen+=part;}if(!loadFen(p,fen))loadFen(p,START_FEN);}else loadFen(p,START_FEN);
    while(in>>token){if(token=="moves"){while(in>>token){Move m;if(parseUciMove(p,token,m))makeMove(p,m);else break;}break;}}
}
}

int main(int argc,char**argv){using namespace prunex;Position pos;loadFen(pos,START_FEN);
    if(argc==3&&std::string_view(argv[1])=="--perft"){
        int d=0;
        if(!parseIntegerToken(argv[2],0,7,d)){std::cerr<<"Invalid depth (expected 0-7)\n";return 2;}
        std::cout<<"Perft depth "<<d<<": "<<perft(pos,d)<<"\n";
        return 0;
    }
    if(argc==4&&std::string_view(argv[1])=="--perft-fen"){
        int d=0;
        if(!loadFen(pos,argv[2])){std::cerr<<"Invalid FEN\n";return 2;}
        if(!parseIntegerToken(argv[3],0,7,d)){std::cerr<<"Invalid depth (expected 0-7)\n";return 2;}
        std::cout<<"Perft depth "<<d<<": "<<perft(pos,d)<<"\n";
        return 0;
    }
    if(argc==4&&std::string_view(argv[1])=="--divide-fen"){
        int d=0;
        if(!loadFen(pos,argv[2])){std::cerr<<"Invalid FEN\n";return 2;}
        if(!parseIntegerToken(argv[3],1,7,d)){std::cerr<<"Invalid depth (expected 1-7)\n";return 2;}
        std::uint64_t total=0;
        for(const Move&m:legalMoves(pos)){Position q=pos;makeMove(q,m);auto n=perft(q,d-1);std::cout<<moveUci(m)<<": "<<n<<"\n";total+=n;}
        std::cout<<"Total: "<<total<<"\n";
        return 0;
    }
    std::string line;while(std::getline(std::cin,line)){std::istringstream in(line);std::string cmd;in>>cmd;
        if(cmd=="uci"){std::cout<<"id name Prunex 0.4.3\nid author Prunex Project\nuciok\n"<<std::flush;}
        else if(cmd=="isready"){std::cout<<"readyok\n"<<std::flush;}
        else if(cmd=="ucinewgame"){loadFen(pos,START_FEN);}
        else if(cmd=="position"){setPosition(pos,line);}
        else if(cmd=="go"){int depth=5;std::string t;while(in>>t)if(t=="depth"&&in>>depth)break;Move best=findBestMove(pos,std::clamp(depth,1,10));std::cout<<"bestmove "<<(best.from>=0?moveUci(best):"0000")<<"\n"<<std::flush;}
        else if(cmd=="stop"){}
        else if(cmd=="quit")break;
        else if(cmd=="d"){for(int r=7;r>=0;--r){for(int f=0;f<8;++f)std::cout<<pieceChar(pos.board[r*16+f])<<' ';std::cout<<'\n';}}
    }return 0;
}
