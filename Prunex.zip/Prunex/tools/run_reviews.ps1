param(
    [Parameter(Mandatory = $true, ParameterSetName = "List")]
    [switch]$ListModels,
    [Parameter(Mandatory = $true, ParameterSetName = "Review")]
    [string]$Models
)

$secureKey = Read-Host -Prompt "OpenAI Platform API key" -AsSecureString
$pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
$exitCode = 1

try {
    $env:OPENAI_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    if ($ListModels) {
        & py tools/openai_review.py --list-models
    } else {
        & py tools/openai_review.py --models $Models
    }
    $exitCode = $LASTEXITCODE
}
finally {
    Remove-Item Env:OPENAI_API_KEY -ErrorAction SilentlyContinue
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    $secureKey.Dispose()
}

exit $exitCode
