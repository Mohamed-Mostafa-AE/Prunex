# Prunex 0.4.3

Prunex is a C++20 chess-engine project with a native Windows desktop interface and a UCI-capable command-line engine.

## Windows 11 desktop build

Requirements: Visual Studio 2022 (Desktop development with C++), CMake 3.20 or newer, and the Windows 10/11 SDK. The graphical application uses the native Win32 API and GDI; no Qt installation is required.

From the project directory:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```

Launch `build\\Release\\Prunex.exe` for the graphical application. The console engine is `build\\Release\\prunex-cli.exe`.

The desktop interface currently includes:

- Click-to-move chessboard with legal-move highlighting
- Human-versus-Prunex play (human plays White)
- Native C++ search with adjustable depth (1–8)
- New game, undo-turn, and board-flip controls
- Check, checkmate, and stalemate status
- Queen promotion by default

Search runs on the UI thread, so the window may temporarily stop responding while Prunex thinks, especially at higher depths. The engine is an early prototype; no Elo rating is claimed.

## Console build and tests

```powershell
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

The console engine supports UCI commands, `--perft DEPTH`, `--perft-fen "FEN" DEPTH`, and `--divide-fen "FEN" DEPTH`. Diagnostic perft commands validate depth ranges (0–7, and 1–7 for divide) and reject malformed input instead of recursing with invalid depths. The regression suite includes the start position, Kiwipete, endgame position 3, standard perft positions 4–6, FEN rejection cases, and search regressions for checkmate, stalemate, and quiet check evasions.

## Current limitations

- The desktop app is Windows-only and has not been compiled on Windows in this Linux build environment.
- The GUI uses the included Prunex search, not Stockfish.
- Search is synchronous; no background search/cancellation yet.
- No PGN import/export, clocks, opening book, transposition table, or Elo measurement.
- Promotions default to queen.

The GUI is an original interface around the separately maintained Prunex engine source. No Stockfish source is included. The Undo control restores a complete player/engine turn when both moves have been played.

## Independent OpenAI model review

A review runner is included at `tools/openai_review.py`. It sends the engine, GUI, and build configuration to each requested model through the OpenAI Responses API and saves the findings under `reviews/`.

```powershell
py -m pip install -r tools\requirements.txt
.\tools\run_reviews.ps1 -ListModels
.\tools\run_reviews.ps1 -Models "model-id-one,model-id-two"
```


Use model IDs returned by `--list-models` and enabled for your Platform project. The PowerShell helper prompts for the key without echoing it, sets it temporarily in the local process environment for the Python call, and removes it afterward. Do not paste it into chat or commit it. API usage may incur charges. The runner was not executed in this build environment because the Platform key is not present in this process.

See [TEST_REPORT.md](TEST_REPORT.md) for the verified test results and remaining limitations.

For first-run Windows GUI verification, use [WINDOWS_GUI_CHECKLIST.md](WINDOWS_GUI_CHECKLIST.md). A GitHub Actions workflow is included at `.github/workflows/windows-build.yml`; pushing the project to GitHub will build the actual Win32 GUI and run all tests on a Windows Server 2022 runner, then publish the two executable artifacts.

## Latest verification (0.4.3)

The current source passes 42/42 CTest cases with GCC 14.2 Release, GCC AddressSanitizer/UndefinedBehaviorSanitizer, and Clang 17 Release. Additional published perft reference counts are listed in `TEST_REPORT.md`. This does not substitute for testing the Win32 GUI on Windows, and no playing-strength rating is claimed.
