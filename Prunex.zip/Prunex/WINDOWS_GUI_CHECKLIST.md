# Prunex Windows GUI Test Checklist

Run this after building on Windows 11 with Visual Studio 2022 and the Windows SDK. Record the Windows version, compiler version, and any failure details.

## Startup and drawing

- [ ] `Prunex.exe` opens without an error.
- [ ] All 64 squares and all 32 starting pieces are visible.
- [ ] Piece glyphs render correctly with the selected Windows font.
- [ ] Board coordinates match the displayed squares.
- [ ] No panel or footer content is clipped at the default window size.

## Board interaction

- [ ] Clicking an empty square does not select a piece.
- [ ] Clicking a white piece selects it.
- [ ] Legal destination squares are highlighted.
- [ ] An illegal move is rejected without changing the position.
- [ ] A legal white move triggers exactly one black engine reply.
- [ ] Flip Board changes the orientation and preserves the position.

## Game controls

- [ ] New Game restores the initial position and clears history.
- [ ] Undo after a complete human move and engine reply restores the position before both moves.
- [ ] Undo after multiple turns returns exactly one full turn each time.
- [ ] Search depth cannot be reduced below 1 or increased above 8.
- [ ] Check, checkmate, and stalemate messages are correct.
- [ ] Promotion produces a queen; this is the current default behavior.

## Responsiveness and stability

- [ ] Close the window during normal play.
- [ ] Try search depth 1, 3, 5, and 8 and record response times.
- [ ] Confirm whether the window freezes while the engine searches; synchronous search is a known limitation.
- [ ] Play at least 20 complete turns and check for rendering/state corruption.

## Test evidence to return

Include screenshots for visual defects, the exact move sequence and FEN for chess-state defects, and any compiler/runtime error text. Do not report an item as passed unless it was executed on Windows.
