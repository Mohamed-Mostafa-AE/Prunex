# Prunex 0.5.1

Prunex is a C++20 chess engine with a native Windows desktop interface and a UCI-capable command-line engine.

## Engine improvements

The 0.5.0 search core adds Zobrist position hashing, a 262,144-entry transposition table, iterative deepening, aspiration windows, principal-variation search, hash/MVV-LVA/killer/history move ordering, late-move reductions, improved quiescence handling, and tapered positional evaluation with pawn-structure, bishop-pair, passed-pawn, and rook-file terms.

Version 0.5.1 adds UCI move-time and clock-based time management. The engine accepts `go movetime` and `go wtime/btime/winc/binc/movestogo` and returns the best move from its last fully completed iterative-deepening iteration when its budget expires.

The engine techniques are implemented in Prunex's own source. No Stockfish source code or neural-network weights are included. No Elo rating is claimed until controlled matches have been completed.

## Windows 11 build

Requirements: Visual Studio 2022 with Desktop development with C++, CMake 3.20+, and the Windows 10/11 SDK.

From the project directory:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

Launch `build\Release\Prunex.exe` for the desktop GUI and `build\Release\prunex-cli.exe` for the UCI console engine.

The GUI supports click-to-move, legal-move highlighting, human-versus-engine play, search depth 1–8, new game, undo-turn, board flip, check/checkmate/stalemate status, and queen promotion by default. Search remains synchronous on the UI thread.

## Regression coverage

The 44-test suite covers standard perft positions, FEN validation, en-passant legality, terminal positions, quiet check evasions, mate-in-one selection, make/undo hash restoration, transposition-table reuse, UCI move-time search, and clock-based search.

See [TEST_REPORT.md](TEST_REPORT.md) and [WINDOWS_GUI_CHECKLIST.md](WINDOWS_GUI_CHECKLIST.md).

## Stockfish 4 and 6 benchmark

The repository's `Prunex versus Stockfish 4 and 6` GitHub Actions workflow builds the official `sf_4` and `sf_6` source tags from [the official Stockfish repository](https://github.com/official-stockfish/Stockfish). It runs 64 games against each version, using 16 opening positions, two repeats, and both colors for Prunex.

Both sides receive the same 100 ms per move, with one search thread per engine. The workflow saves PGNs and JSON score summaries as downloadable artifacts. This is a fixed-move-time match, not an Elo rating or a large-scale SPRT. Match results must be reviewed before claiming Prunex beats either opponent.

## Independent OpenAI model review

A review runner is included at `tools/openai_review.py`. It sends the engine, GUI, and build configuration to each requested model through the OpenAI Responses API and saves findings under `reviews/`.

```powershell
py -m pip install -r tools\requirements.txt
.\tools\run_reviews.ps1 -ListModels
.\tools\run_reviews.ps1 -Models "model-id-one,model-id-two"
```

Use model IDs returned by `--list-models` and enabled for your Platform project. The helper prompts for the key without echoing it and removes it from the process environment afterward. Do not paste a key into chat or commit it. API usage may incur charges.
